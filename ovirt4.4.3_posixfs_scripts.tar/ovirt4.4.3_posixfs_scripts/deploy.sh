#!/bin/bash

while read line
do
	file=`basename "$line"`
	echo $file
	echo $target:$line
	if [[ "$file" == "constants.py" ]]; then
		if [[ "$line" == *"ovirt_hosted_engine_setup"* ]]; then
			cp setup_constants.py $target:$line
		else
			cp ha_constants.py $target:$line
		fi
	else
		cp $file $target:$line
	fi
done < target_files.txt
