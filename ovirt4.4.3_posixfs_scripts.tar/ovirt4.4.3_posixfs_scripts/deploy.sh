#!/bin/bash

while read line
do
	file=`basename "$line"`
	echo $file
	if [[ "$file" == "constants.py" ]]; then
		if [[ "$line" == *"ovirt_hosted_engine_setup"* ]]; then
			cp setup_constants.py $line
		else
			cp ha_constants.py $line
		fi
	else
		cp $file $line
	fi
done < target_files.txt
